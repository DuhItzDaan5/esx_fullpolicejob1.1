USE `essentialmode`;

INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_police', 'Police', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_police', 'Police', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_police', 'Police', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('police','Politie')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('police',0,'recruit','Aspirant',20,'{}','{}'),
	('police',1,'officer','Surveillant',40,'{}','{}'),
	('police',2,'sergeant','Agent',60,'{}','{}'),
	('police',3,'lieutenant','Hoofd Agent',85,'{}','{}'),
	('police',4,'politie1','Brigadiert',100,'{}','{}')
	('police',5,'politie2','Inspecteur',135,'{}','{}')
	('police',6,'politie3','Hoofd Inspecteur ',185,'{}','{}')
	('police',7,'politie4','Commissaris ',200,'{}','{}')
	('police',8,'politie5','Hoofd Commissaris ',235,'{}','{}')
	('police',9,'boss','Eerste Hoofd Commissaris ',255,'{}','{}')
;

CREATE TABLE `fine_types` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`label` varchar(255) DEFAULT NULL,
	`amount` int(11) DEFAULT NULL,
	`category` int(11) DEFAULT NULL,

	PRIMARY KEY (`id`)
);

INSERT INTO `fine_types` (`id`, `label`, `amount`, `category`) VALUES
(1, 'Onnodig Claxoneren', 100, 0),
(2, 'Kruis een doorgetrokke lijn', 150, 0),
(3, 'Spookrijden', 750, 0),
(4, 'Ongeoorloofde omkeer', 250, 0),
(5, 'Associaal rijgedrag', 150, 0),
(6, 'Het niet respecteren van hulpverleners', 100, 0),
(7, 'Gevaarlijk / verboden stoppen', 150, 0),
(8, 'Illegaal parkeren', 500, 0),
(9, 'Niet respecteren van de prioriteit aan de rechterkant', 70, 0),
(10, 'Niet-naleving van een prioritair voertuig', 90, 0),
(11, 'Niet stoppen voor een stop bord', 105, 0),
(12, 'Het Rode Licht Genegeerd', 370, 0),
(13, 'Gevaarlijk inhalen', 100, 0),
(14, 'Rijden in een illegaal voertuig', 100, 0),
(15, 'Rijden zonder rijbewijs', 1500, 0),
(16, 'Gebruik van geweld', 800, 0),
(17, '15-30 KMH te hard', 300, 0),
(18, '30 KMH te hard', 300, 0),
(19, '50 KHM te hard ', 500, 0),
(20, '70 KMH te hard ', 750, 0),
(21, 'Obstakel van het verkeer', 110, 1),
(22, 'Degradatie van de openbare weg', 90, 1),
(23, 'Problemen met openbare orde', 90, 1),
(24, 'De werking van de politie belemmeren', 350, 1),
(25, 'Belediging van burger', 75, 1),
(26, 'Verontwaardiging tegen een politie agent', 110, 1),
(27, 'Verbale bedreiging of intimidatie richting burger', 90, 1),
(28, 'Verbale bedreiging of intimidatie van een politieagent', 150, 1),
(29, 'Illegale praktijken', 250, 1),
(30, 'Poging tot corruptie', 1500, 1),
(31, 'Wapen trekken zonder reden', 120, 2),
(32, 'Wapen zonder vergunning', 300, 2),
(33, 'Poging tot stelen van een voertuig', 600, 2),
(34, 'Bezit van zware wapens', 2750, 2),
(35, 'Bezit van illegaal wapen(s)', 300, 2),
(36, 'Auto diefstal', 1800, 2),
(37, 'Verkoop van drugs', 1500, 2),
(38, 'Medicijnproductie', 1500, 2),
(39, 'Het bezit van medicijnen', 650, 2),
(40, 'Poging tot een ontvoering', 1500, 2),
(41, 'Burger overval', 2000, 2),
(42, 'Overval', 2750, 2),
(43, 'Winkel overval', 3500, 2),
(44, 'Bank overval', 4500, 2),
(45, 'Gewelddadig tegen burgers', 2000, 3),
(46, 'Gewelddadig tegen een agent', 2500, 3),
(47, 'Poging tot moord op een burger', 3000, 3),
(48, 'Poging tot moord op een agent', 5000, 3),
(49, 'Moord op een burger', 10000, 3),
(50, 'Moord op een agent', 15000, 3),
(51, 'Involuntary manslaughter', 1800, 3),
(52, 'Fraude', 25000, 2);
;
