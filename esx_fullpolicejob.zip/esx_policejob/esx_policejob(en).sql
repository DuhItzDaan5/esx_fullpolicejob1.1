USE `essentialmode`;

INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_police', 'Police', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_police', 'Police', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_police', 'Police', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('police','LSPD')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('police',0,'recruit','Pupil',20,'{}','{}'),
	('police',1,'officer','Constable',40,'{}','{}'),
	('police',2,'sergeant','Senior Constable',60,'{}','{}'),
	('police',3,'lieutenant','Chief Inspector',85,'{}','{}'),
	('police',4,'superintended','Superintendent',100,'{}','{}')
	('police',5,'chiefintendent','Chief Superintendent',135,'{}','{}')
	('police',6,'deputychief','Deputy Chief Constable ',155,'{}','{}')
	('police',7,'boss','Chief Constable ',185,'{}','{}')
;

CREATE TABLE `fine_types` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`label` varchar(255) DEFAULT NULL,
	`amount` int(11) DEFAULT NULL,
	`category` int(11) DEFAULT NULL,

	PRIMARY KEY (`id`)
);

INSERT INTO `fine_types` (label, amount, category) VALUES
('Abuse of the horn', 30,0),
('Cross a solid line', 40,0),
('Reverse traffic', 250.0),
('U-turn not allowed', 250.0),
('Off-road traffic', 170.0),
('Non-compliance with safety distances', 30,0),
('Dangerous / prohibited stop', 150.0),
('Disturbing / prohibited parking', 70.0),
('Failure to respect the right priority', 70,0),
('Non-compliance with a priority vehicle', 90.0),
('Non-compliance with a stop sign', 105.0),
('Failure to comply with a red light', 130.0),
('Dangerous overtaking', 100.0),
('Vehicle not in good condition', 100.0),
('Driving without a license', 1500.0),
('Hit and run', 800.0),
('Speeding <5 km / h', 90.0),
('Speeding 5-15 km / h', 120.0),
('Speeding 15-30 km / h', 180.0),
('Speeding> 30 km / h', 300.0),
('Traffic obstruction', 110,1),
('Degradation of the public highway', 90,1),
('Trouble with public order', 90,1),
('Obstruction of police operation', 130.1),
('Insult to / between civilians', 75.1),
('Contempt of police officer', 110,1),
('Verbal threat or intimidation against civilians', 90,1),
('Verbal threat or intimidation against the police', 150,1),
('Illegal demonstration', 250.1),
('Attempted corruption', 1500.1),
('White weapon out in town', 120,2),
('Lethal weapon out in town', 300.2),
('Unauthorized carrying of weapons (lack of license)', 600.2),
('Illegal weapon carrying', 700.2),
('Taken in flag lockpick', 300.2),
('Car theft', 1800.2),
('Sale of drugs', 1500.2),
('Drug making', 1500.2),
('Possession of drugs', 650.2),
('Taking civil hostage', 1500.2),
('State agent take-over', 2000,2),
('Private robbery', 650.2),
('Store robbery', 650.2),
('Bank robbery', 1500.2),
('Tir sur civil', 2000,3),
('Shooting at the agent of the state', 2500.3),
('Attempted murder on a civilian', 3000.3),
('Attempted Murder on State Agent', 5000.3),
('Murder on civilian', 10000.3),
('Dies on state agent', 30000.3),
('Involuntary Murder', 1800.3),
('Business scam', 2000,2)
;
